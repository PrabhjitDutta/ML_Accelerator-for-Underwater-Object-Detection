-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
-- Tool Version Limit: 2026.06
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity y26_conv_top_control_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 8;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    interrupt             :out  STD_LOGIC;
    X                     :out  STD_LOGIC_VECTOR(63 downto 0);
    Wt                    :out  STD_LOGIC_VECTOR(63 downto 0);
    wsc                   :out  STD_LOGIC_VECTOR(63 downto 0);
    bias                  :out  STD_LOGIC_VECTOR(63 downto 0);
    step_v                :out  STD_LOGIC_VECTOR(63 downto 0);
    lo_v                  :out  STD_LOGIC_VECTOR(63 downto 0);
    Y                     :out  STD_LOGIC_VECTOR(63 downto 0);
    H                     :out  STD_LOGIC_VECTOR(31 downto 0);
    W                     :out  STD_LOGIC_VECTOR(31 downto 0);
    oc                    :out  STD_LOGIC_VECTOR(31 downto 0);
    ic                    :out  STD_LOGIC_VECTOR(31 downto 0);
    kh                    :out  STD_LOGIC_VECTOR(31 downto 0);
    kw                    :out  STD_LOGIC_VECTOR(31 downto 0);
    sh                    :out  STD_LOGIC_VECTOR(31 downto 0);
    sw                    :out  STD_LOGIC_VECTOR(31 downto 0);
    ph                    :out  STD_LOGIC_VECTOR(31 downto 0);
    pw                    :out  STD_LOGIC_VECTOR(31 downto 0);
    groups                :out  STD_LOGIC_VECTOR(31 downto 0);
    act                   :out  STD_LOGIC_VECTOR(31 downto 0);
    perch                 :out  STD_LOGIC_VECTOR(31 downto 0);
    step                  :out  STD_LOGIC_VECTOR(31 downto 0);
    lo                    :out  STD_LOGIC_VECTOR(31 downto 0);
    ap_start              :out  STD_LOGIC;
    ap_done               :in   STD_LOGIC;
    ap_ready              :in   STD_LOGIC;
    ap_idle               :in   STD_LOGIC
);
end entity y26_conv_top_control_s_axi;

-- ------------------------Address Info-------------------
-- Protocol Used: ap_ctrl_hs
--
-- 0x00 : Control signals
--        bit 0  - ap_start (Read/Write/COH)
--        bit 1  - ap_done (Read/COR)
--        bit 2  - ap_idle (Read)
--        bit 3  - ap_ready (Read/COR)
--        bit 7  - auto_restart (Read/Write)
--        bit 9  - interrupt (Read)
--        others - reserved
-- 0x04 : Global Interrupt Enable Register
--        bit 0  - Global Interrupt Enable (Read/Write)
--        others - reserved
-- 0x08 : IP Interrupt Enable Register (Read/Write)
--        bit 0 - enable ap_done interrupt (Read/Write)
--        bit 1 - enable ap_ready interrupt (Read/Write)
--        others - reserved
-- 0x0c : IP Interrupt Status Register (Read/TOW)
--        bit 0 - ap_done (Read/TOW)
--        bit 1 - ap_ready (Read/TOW)
--        others - reserved
-- 0x10 : Data signal of X
--        bit 31~0 - X[31:0] (Read/Write)
-- 0x14 : Data signal of X
--        bit 31~0 - X[63:32] (Read/Write)
-- 0x18 : reserved
-- 0x1c : Data signal of Wt
--        bit 31~0 - Wt[31:0] (Read/Write)
-- 0x20 : Data signal of Wt
--        bit 31~0 - Wt[63:32] (Read/Write)
-- 0x24 : reserved
-- 0x28 : Data signal of wsc
--        bit 31~0 - wsc[31:0] (Read/Write)
-- 0x2c : Data signal of wsc
--        bit 31~0 - wsc[63:32] (Read/Write)
-- 0x30 : reserved
-- 0x34 : Data signal of bias
--        bit 31~0 - bias[31:0] (Read/Write)
-- 0x38 : Data signal of bias
--        bit 31~0 - bias[63:32] (Read/Write)
-- 0x3c : reserved
-- 0x40 : Data signal of step_v
--        bit 31~0 - step_v[31:0] (Read/Write)
-- 0x44 : Data signal of step_v
--        bit 31~0 - step_v[63:32] (Read/Write)
-- 0x48 : reserved
-- 0x4c : Data signal of lo_v
--        bit 31~0 - lo_v[31:0] (Read/Write)
-- 0x50 : Data signal of lo_v
--        bit 31~0 - lo_v[63:32] (Read/Write)
-- 0x54 : reserved
-- 0x58 : Data signal of Y
--        bit 31~0 - Y[31:0] (Read/Write)
-- 0x5c : Data signal of Y
--        bit 31~0 - Y[63:32] (Read/Write)
-- 0x60 : reserved
-- 0x64 : Data signal of H
--        bit 31~0 - H[31:0] (Read/Write)
-- 0x68 : reserved
-- 0x6c : Data signal of W
--        bit 31~0 - W[31:0] (Read/Write)
-- 0x70 : reserved
-- 0x74 : Data signal of oc
--        bit 31~0 - oc[31:0] (Read/Write)
-- 0x78 : reserved
-- 0x7c : Data signal of ic
--        bit 31~0 - ic[31:0] (Read/Write)
-- 0x80 : reserved
-- 0x84 : Data signal of kh
--        bit 31~0 - kh[31:0] (Read/Write)
-- 0x88 : reserved
-- 0x8c : Data signal of kw
--        bit 31~0 - kw[31:0] (Read/Write)
-- 0x90 : reserved
-- 0x94 : Data signal of sh
--        bit 31~0 - sh[31:0] (Read/Write)
-- 0x98 : reserved
-- 0x9c : Data signal of sw
--        bit 31~0 - sw[31:0] (Read/Write)
-- 0xa0 : reserved
-- 0xa4 : Data signal of ph
--        bit 31~0 - ph[31:0] (Read/Write)
-- 0xa8 : reserved
-- 0xac : Data signal of pw
--        bit 31~0 - pw[31:0] (Read/Write)
-- 0xb0 : reserved
-- 0xb4 : Data signal of groups
--        bit 31~0 - groups[31:0] (Read/Write)
-- 0xb8 : reserved
-- 0xbc : Data signal of act
--        bit 31~0 - act[31:0] (Read/Write)
-- 0xc0 : reserved
-- 0xc4 : Data signal of perch
--        bit 31~0 - perch[31:0] (Read/Write)
-- 0xc8 : reserved
-- 0xcc : Data signal of step
--        bit 31~0 - step[31:0] (Read/Write)
-- 0xd0 : reserved
-- 0xd4 : Data signal of lo
--        bit 31~0 - lo[31:0] (Read/Write)
-- 0xd8 : reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of y26_conv_top_control_s_axi is
attribute DowngradeIPIdentifiedWarnings : STRING;
attribute DowngradeIPIdentifiedWarnings of behave : architecture is "yes";
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_AP_CTRL       : INTEGER := 16#00#;
    constant ADDR_GIE           : INTEGER := 16#04#;
    constant ADDR_IER           : INTEGER := 16#08#;
    constant ADDR_ISR           : INTEGER := 16#0c#;
    constant ADDR_X_DATA_0      : INTEGER := 16#10#;
    constant ADDR_X_DATA_1      : INTEGER := 16#14#;
    constant ADDR_X_CTRL        : INTEGER := 16#18#;
    constant ADDR_WT_DATA_0     : INTEGER := 16#1c#;
    constant ADDR_WT_DATA_1     : INTEGER := 16#20#;
    constant ADDR_WT_CTRL       : INTEGER := 16#24#;
    constant ADDR_WSC_DATA_0    : INTEGER := 16#28#;
    constant ADDR_WSC_DATA_1    : INTEGER := 16#2c#;
    constant ADDR_WSC_CTRL      : INTEGER := 16#30#;
    constant ADDR_BIAS_DATA_0   : INTEGER := 16#34#;
    constant ADDR_BIAS_DATA_1   : INTEGER := 16#38#;
    constant ADDR_BIAS_CTRL     : INTEGER := 16#3c#;
    constant ADDR_STEP_V_DATA_0 : INTEGER := 16#40#;
    constant ADDR_STEP_V_DATA_1 : INTEGER := 16#44#;
    constant ADDR_STEP_V_CTRL   : INTEGER := 16#48#;
    constant ADDR_LO_V_DATA_0   : INTEGER := 16#4c#;
    constant ADDR_LO_V_DATA_1   : INTEGER := 16#50#;
    constant ADDR_LO_V_CTRL     : INTEGER := 16#54#;
    constant ADDR_Y_DATA_0      : INTEGER := 16#58#;
    constant ADDR_Y_DATA_1      : INTEGER := 16#5c#;
    constant ADDR_Y_CTRL        : INTEGER := 16#60#;
    constant ADDR_H_DATA_0      : INTEGER := 16#64#;
    constant ADDR_H_CTRL        : INTEGER := 16#68#;
    constant ADDR_W_DATA_0      : INTEGER := 16#6c#;
    constant ADDR_W_CTRL        : INTEGER := 16#70#;
    constant ADDR_OC_DATA_0     : INTEGER := 16#74#;
    constant ADDR_OC_CTRL       : INTEGER := 16#78#;
    constant ADDR_IC_DATA_0     : INTEGER := 16#7c#;
    constant ADDR_IC_CTRL       : INTEGER := 16#80#;
    constant ADDR_KH_DATA_0     : INTEGER := 16#84#;
    constant ADDR_KH_CTRL       : INTEGER := 16#88#;
    constant ADDR_KW_DATA_0     : INTEGER := 16#8c#;
    constant ADDR_KW_CTRL       : INTEGER := 16#90#;
    constant ADDR_SH_DATA_0     : INTEGER := 16#94#;
    constant ADDR_SH_CTRL       : INTEGER := 16#98#;
    constant ADDR_SW_DATA_0     : INTEGER := 16#9c#;
    constant ADDR_SW_CTRL       : INTEGER := 16#a0#;
    constant ADDR_PH_DATA_0     : INTEGER := 16#a4#;
    constant ADDR_PH_CTRL       : INTEGER := 16#a8#;
    constant ADDR_PW_DATA_0     : INTEGER := 16#ac#;
    constant ADDR_PW_CTRL       : INTEGER := 16#b0#;
    constant ADDR_GROUPS_DATA_0 : INTEGER := 16#b4#;
    constant ADDR_GROUPS_CTRL   : INTEGER := 16#b8#;
    constant ADDR_ACT_DATA_0    : INTEGER := 16#bc#;
    constant ADDR_ACT_CTRL      : INTEGER := 16#c0#;
    constant ADDR_PERCH_DATA_0  : INTEGER := 16#c4#;
    constant ADDR_PERCH_CTRL    : INTEGER := 16#c8#;
    constant ADDR_STEP_DATA_0   : INTEGER := 16#cc#;
    constant ADDR_STEP_CTRL     : INTEGER := 16#d0#;
    constant ADDR_LO_DATA_0     : INTEGER := 16#d4#;
    constant ADDR_LO_CTRL       : INTEGER := 16#d8#;
    constant ADDR_BITS         : INTEGER := 8;

    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    signal BVALID_t            : STD_LOGIC;
    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    -- internal registers
    signal int_ap_idle         : STD_LOGIC := '0';
    signal int_ap_ready        : STD_LOGIC := '0';
    signal task_ap_ready       : STD_LOGIC;
    signal int_ap_done         : STD_LOGIC := '0';
    signal task_ap_done        : STD_LOGIC;
    signal int_task_ap_done    : STD_LOGIC := '0';
    signal int_ap_start        : STD_LOGIC := '0';
    signal int_interrupt       : STD_LOGIC := '0';
    signal int_auto_restart    : STD_LOGIC := '0';
    signal auto_restart_status : STD_LOGIC := '0';
    signal auto_restart_done   : STD_LOGIC;
    signal int_gie             : STD_LOGIC := '0';
    signal int_ier             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_isr             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_X               : UNSIGNED(63 downto 0) := (others => '0');
    signal int_Wt              : UNSIGNED(63 downto 0) := (others => '0');
    signal int_wsc             : UNSIGNED(63 downto 0) := (others => '0');
    signal int_bias            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_step_v          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_lo_v            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_Y               : UNSIGNED(63 downto 0) := (others => '0');
    signal int_H               : UNSIGNED(31 downto 0) := (others => '0');
    signal int_W               : UNSIGNED(31 downto 0) := (others => '0');
    signal int_oc              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_ic              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_kh              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_kw              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_sh              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_sw              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_ph              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_pw              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_groups          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_act             : UNSIGNED(31 downto 0) := (others => '0');
    signal int_perch           : UNSIGNED(31 downto 0) := (others => '0');
    signal int_step            : UNSIGNED(31 downto 0) := (others => '0');
    signal int_lo              : UNSIGNED(31 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BVALID_t  <=  '1' when wstate = wrresp else '0';
    BVALID    <=  BVALID_t;
    BRESP     <=  "00";  -- OKAY
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY, BVALID_t)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1' and BVALID_t = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 2) & (1 downto 0 => '0'));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_AP_CTRL =>
                        rdata_data(9) <= int_interrupt;
                        rdata_data(7) <= int_auto_restart;
                        rdata_data(3) <= int_ap_ready;
                        rdata_data(2) <= int_ap_idle;
                        rdata_data(1) <= int_task_ap_done;
                        rdata_data(0) <= int_ap_start;
                    when ADDR_GIE =>
                        rdata_data(0) <= int_gie;
                    when ADDR_IER =>
                        rdata_data(1 downto 0) <= int_ier;
                    when ADDR_ISR =>
                        rdata_data(1 downto 0) <= int_isr;
                    when ADDR_X_DATA_0 =>
                        rdata_data <= RESIZE(int_X(31 downto 0), 32);
                    when ADDR_X_DATA_1 =>
                        rdata_data <= RESIZE(int_X(63 downto 32), 32);
                    when ADDR_WT_DATA_0 =>
                        rdata_data <= RESIZE(int_Wt(31 downto 0), 32);
                    when ADDR_WT_DATA_1 =>
                        rdata_data <= RESIZE(int_Wt(63 downto 32), 32);
                    when ADDR_WSC_DATA_0 =>
                        rdata_data <= RESIZE(int_wsc(31 downto 0), 32);
                    when ADDR_WSC_DATA_1 =>
                        rdata_data <= RESIZE(int_wsc(63 downto 32), 32);
                    when ADDR_BIAS_DATA_0 =>
                        rdata_data <= RESIZE(int_bias(31 downto 0), 32);
                    when ADDR_BIAS_DATA_1 =>
                        rdata_data <= RESIZE(int_bias(63 downto 32), 32);
                    when ADDR_STEP_V_DATA_0 =>
                        rdata_data <= RESIZE(int_step_v(31 downto 0), 32);
                    when ADDR_STEP_V_DATA_1 =>
                        rdata_data <= RESIZE(int_step_v(63 downto 32), 32);
                    when ADDR_LO_V_DATA_0 =>
                        rdata_data <= RESIZE(int_lo_v(31 downto 0), 32);
                    when ADDR_LO_V_DATA_1 =>
                        rdata_data <= RESIZE(int_lo_v(63 downto 32), 32);
                    when ADDR_Y_DATA_0 =>
                        rdata_data <= RESIZE(int_Y(31 downto 0), 32);
                    when ADDR_Y_DATA_1 =>
                        rdata_data <= RESIZE(int_Y(63 downto 32), 32);
                    when ADDR_H_DATA_0 =>
                        rdata_data <= RESIZE(int_H(31 downto 0), 32);
                    when ADDR_W_DATA_0 =>
                        rdata_data <= RESIZE(int_W(31 downto 0), 32);
                    when ADDR_OC_DATA_0 =>
                        rdata_data <= RESIZE(int_oc(31 downto 0), 32);
                    when ADDR_IC_DATA_0 =>
                        rdata_data <= RESIZE(int_ic(31 downto 0), 32);
                    when ADDR_KH_DATA_0 =>
                        rdata_data <= RESIZE(int_kh(31 downto 0), 32);
                    when ADDR_KW_DATA_0 =>
                        rdata_data <= RESIZE(int_kw(31 downto 0), 32);
                    when ADDR_SH_DATA_0 =>
                        rdata_data <= RESIZE(int_sh(31 downto 0), 32);
                    when ADDR_SW_DATA_0 =>
                        rdata_data <= RESIZE(int_sw(31 downto 0), 32);
                    when ADDR_PH_DATA_0 =>
                        rdata_data <= RESIZE(int_ph(31 downto 0), 32);
                    when ADDR_PW_DATA_0 =>
                        rdata_data <= RESIZE(int_pw(31 downto 0), 32);
                    when ADDR_GROUPS_DATA_0 =>
                        rdata_data <= RESIZE(int_groups(31 downto 0), 32);
                    when ADDR_ACT_DATA_0 =>
                        rdata_data <= RESIZE(int_act(31 downto 0), 32);
                    when ADDR_PERCH_DATA_0 =>
                        rdata_data <= RESIZE(int_perch(31 downto 0), 32);
                    when ADDR_STEP_DATA_0 =>
                        rdata_data <= RESIZE(int_step(31 downto 0), 32);
                    when ADDR_LO_DATA_0 =>
                        rdata_data <= RESIZE(int_lo(31 downto 0), 32);
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    interrupt            <= int_interrupt;
    ap_start             <= int_ap_start;
    task_ap_done         <= (ap_done and not auto_restart_status) or auto_restart_done;
    task_ap_ready        <= ap_ready and not int_auto_restart;
    auto_restart_done    <= auto_restart_status and (ap_idle and not int_ap_idle);
    X                    <= STD_LOGIC_VECTOR(int_X);
    Wt                   <= STD_LOGIC_VECTOR(int_Wt);
    wsc                  <= STD_LOGIC_VECTOR(int_wsc);
    bias                 <= STD_LOGIC_VECTOR(int_bias);
    step_v               <= STD_LOGIC_VECTOR(int_step_v);
    lo_v                 <= STD_LOGIC_VECTOR(int_lo_v);
    Y                    <= STD_LOGIC_VECTOR(int_Y);
    H                    <= STD_LOGIC_VECTOR(int_H);
    W                    <= STD_LOGIC_VECTOR(int_W);
    oc                   <= STD_LOGIC_VECTOR(int_oc);
    ic                   <= STD_LOGIC_VECTOR(int_ic);
    kh                   <= STD_LOGIC_VECTOR(int_kh);
    kw                   <= STD_LOGIC_VECTOR(int_kw);
    sh                   <= STD_LOGIC_VECTOR(int_sh);
    sw                   <= STD_LOGIC_VECTOR(int_sw);
    ph                   <= STD_LOGIC_VECTOR(int_ph);
    pw                   <= STD_LOGIC_VECTOR(int_pw);
    groups               <= STD_LOGIC_VECTOR(int_groups);
    act                  <= STD_LOGIC_VECTOR(int_act);
    perch                <= STD_LOGIC_VECTOR(int_perch);
    step                 <= STD_LOGIC_VECTOR(int_step);
    lo                   <= STD_LOGIC_VECTOR(int_lo);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_interrupt <= '0';
            elsif (ACLK_EN = '1') then
                if (int_gie = '1' and (int_isr(0) or int_isr(1)) = '1') then
                    int_interrupt <= '1';
                else
                    int_interrupt <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_start <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1' and WDATA(0) = '1') then
                    int_ap_start <= '1';
                elsif (ap_ready = '1') then
                    int_ap_start <= int_auto_restart; -- clear on handshake/auto restart
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_done <= ap_done;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_task_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_done = '1') then
                    int_task_ap_done <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_task_ap_done <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_idle <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_idle <= ap_idle;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_ready <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_ready = '1') then
                    int_ap_ready <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_ap_ready <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_auto_restart <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1') then
                    int_auto_restart <= WDATA(7);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                auto_restart_status <= '0';
            elsif (ACLK_EN = '1') then
                if (int_auto_restart = '1') then
                    auto_restart_status <= '1';
                elsif (ap_idle = '1') then
                    auto_restart_status <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_gie <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GIE and WSTRB(0) = '1') then
                    int_gie <= WDATA(0);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ier <= (others=>'0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IER and WSTRB(0) = '1') then
                    int_ier <= UNSIGNED(WDATA(1 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(0) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(0) = '1' and ap_done = '1') then
                    int_isr(0) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(0) <= int_isr(0) xor WDATA(0); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(1) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(1) = '1' and ap_ready = '1') then
                    int_isr(1) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(1) <= int_isr(1) xor WDATA(1); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_X(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_DATA_0) then
                    int_X(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_X(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_X(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_DATA_1) then
                    int_X(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_X(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_Wt(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WT_DATA_0) then
                    int_Wt(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_Wt(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_Wt(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WT_DATA_1) then
                    int_Wt(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_Wt(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_wsc(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WSC_DATA_0) then
                    int_wsc(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_wsc(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_wsc(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WSC_DATA_1) then
                    int_wsc(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_wsc(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_bias(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BIAS_DATA_0) then
                    int_bias(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_bias(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_bias(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BIAS_DATA_1) then
                    int_bias(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_bias(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_step_v(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_STEP_V_DATA_0) then
                    int_step_v(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_step_v(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_step_v(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_STEP_V_DATA_1) then
                    int_step_v(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_step_v(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_lo_v(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_LO_V_DATA_0) then
                    int_lo_v(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_lo_v(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_lo_v(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_LO_V_DATA_1) then
                    int_lo_v(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_lo_v(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_Y(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Y_DATA_0) then
                    int_Y(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_Y(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_Y(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Y_DATA_1) then
                    int_Y(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_Y(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_H(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_H_DATA_0) then
                    int_H(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_H(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_W(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_W_DATA_0) then
                    int_W(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_W(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_oc(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_OC_DATA_0) then
                    int_oc(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_oc(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ic(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IC_DATA_0) then
                    int_ic(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ic(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_kh(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_KH_DATA_0) then
                    int_kh(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_kh(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_kw(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_KW_DATA_0) then
                    int_kw(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_kw(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sh(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SH_DATA_0) then
                    int_sh(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sh(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_sw(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SW_DATA_0) then
                    int_sw(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_sw(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ph(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PH_DATA_0) then
                    int_ph(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ph(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_pw(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PW_DATA_0) then
                    int_pw(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_pw(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_groups(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GROUPS_DATA_0) then
                    int_groups(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_groups(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_act(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_ACT_DATA_0) then
                    int_act(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_act(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_perch(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PERCH_DATA_0) then
                    int_perch(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_perch(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_step(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_STEP_DATA_0) then
                    int_step(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_step(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_lo(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_LO_DATA_0) then
                    int_lo(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_lo(31 downto 0));
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
