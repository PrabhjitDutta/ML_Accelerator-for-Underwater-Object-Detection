# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  #Adding Group
  set group_0 [ipgui::add_group $IPINST -name "group 0" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_gmem_act}]
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_ENABLE_ID_PORTS" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_ID_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_DATA_WIDTH" -parent ${group_0} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_ENABLE_USER_PORTS" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_AWUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_WUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_BUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_ARUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_RUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_USER_VALUE" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_PROT_VALUE" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_ACT_CACHE_VALUE" -parent ${group_0}

  #Adding Group
  set group_1 [ipgui::add_group $IPINST -name "group 1" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_gmem_wt}]
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_ENABLE_ID_PORTS" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_ID_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_DATA_WIDTH" -parent ${group_1} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_ENABLE_USER_PORTS" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_AWUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_WUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_BUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_ARUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_RUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_USER_VALUE" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_PROT_VALUE" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_WT_CACHE_VALUE" -parent ${group_1}

  #Adding Group
  set group_2 [ipgui::add_group $IPINST -name "group 2" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_gmem_scale}]
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_ENABLE_ID_PORTS" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_ID_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_DATA_WIDTH" -parent ${group_2} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_ENABLE_USER_PORTS" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_AWUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_WUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_BUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_ARUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_RUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_USER_VALUE" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_PROT_VALUE" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_SCALE_CACHE_VALUE" -parent ${group_2}

  #Adding Group
  set group_3 [ipgui::add_group $IPINST -name "group 3" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_gmem_out}]
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_ENABLE_ID_PORTS" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_ID_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_DATA_WIDTH" -parent ${group_3} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_ENABLE_USER_PORTS" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_AWUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_WUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_BUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_ARUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_RUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_USER_VALUE" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_PROT_VALUE" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_OUT_CACHE_VALUE" -parent ${group_3}

  #Adding Group
  set group_4 [ipgui::add_group $IPINST -name "group 4" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_gmem_code}]
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_ENABLE_ID_PORTS" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_ID_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_DATA_WIDTH" -parent ${group_4} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_ENABLE_USER_PORTS" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_AWUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_WUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_BUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_ARUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_RUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_USER_VALUE" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_PROT_VALUE" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_GMEM_CODE_CACHE_VALUE" -parent ${group_4}



}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_ACT_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_ACT_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_ACT_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_ACT_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_ACT_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_ACT_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_ACT_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_ACT_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_ACT_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_ACT_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_ACT_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_ACT_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_ACT_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_ACT_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_WT_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_WT_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_WT_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_WT_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_WT_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_WT_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_WT_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_WT_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_WT_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_WT_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_WT_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_WT_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_WT_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_WT_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_WT_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_WT_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_WT_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_WT_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_WT_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_WT_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_WT_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_WT_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_WT_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_WT_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_WT_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_SCALE_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_SCALE_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_OUT_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_OUT_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_OUT_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_OUT_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_OUT_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_OUT_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_OUT_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_OUT_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_OUT_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_OUT_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_OUT_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_OUT_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_OUT_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_OUT_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_CODE_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_CODE_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_CODE_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_GMEM_CODE_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_GMEM_CODE_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_CODE_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_CODE_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_CODE_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_CODE_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_GMEM_CODE_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_CODE_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE { PARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_CODE_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE { PARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_GMEM_CODE_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE { PARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_GMEM_CODE_CACHE_VALUE
	return true
}


proc update_MODELPARAM_VALUE.C_S_AXI_CONTROL_ADDR_WIDTH { MODELPARAM_VALUE.C_S_AXI_CONTROL_ADDR_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	# WARNING: There is no corresponding user parameter named "C_S_AXI_CONTROL_ADDR_WIDTH". Setting updated value from the model parameter.
set_property value 9 ${MODELPARAM_VALUE.C_S_AXI_CONTROL_ADDR_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH PARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH PARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE PARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE PARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE PARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_ACT_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH PARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH PARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE PARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE PARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE PARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_WT_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH PARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH PARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE PARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE PARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE PARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_SCALE_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH PARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH PARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE PARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE PARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE PARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_OUT_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH PARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH PARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH PARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE PARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE PARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE PARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_GMEM_CODE_CACHE_VALUE}
}

