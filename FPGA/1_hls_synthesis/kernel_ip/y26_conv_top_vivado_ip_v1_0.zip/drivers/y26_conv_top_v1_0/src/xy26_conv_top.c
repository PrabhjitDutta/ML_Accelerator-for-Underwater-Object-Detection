// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xy26_conv_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XY26_conv_top_CfgInitialize(XY26_conv_top *InstancePtr, XY26_conv_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XY26_conv_top_Start(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XY26_conv_top_IsDone(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XY26_conv_top_IsIdle(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XY26_conv_top_IsReady(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XY26_conv_top_EnableAutoRestart(XY26_conv_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XY26_conv_top_DisableAutoRestart(XY26_conv_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

void XY26_conv_top_Set_X(XY26_conv_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_X_DATA, (u32)(Data));
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_conv_top_Get_X(XY26_conv_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_X_DATA);
    Data += (u64)XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XY26_conv_top_Set_Wt(XY26_conv_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WT_DATA, (u32)(Data));
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WT_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_conv_top_Get_Wt(XY26_conv_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WT_DATA);
    Data += (u64)XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WT_DATA + 4) << 32;
    return Data;
}

void XY26_conv_top_Set_wsc(XY26_conv_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WSC_DATA, (u32)(Data));
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WSC_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_conv_top_Get_wsc(XY26_conv_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WSC_DATA);
    Data += (u64)XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_WSC_DATA + 4) << 32;
    return Data;
}

void XY26_conv_top_Set_bias(XY26_conv_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_conv_top_Get_bias(XY26_conv_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XY26_conv_top_Set_step_v(XY26_conv_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_STEP_V_DATA, (u32)(Data));
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_STEP_V_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_conv_top_Get_step_v(XY26_conv_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_STEP_V_DATA);
    Data += (u64)XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_STEP_V_DATA + 4) << 32;
    return Data;
}

void XY26_conv_top_Set_lo_v(XY26_conv_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_LO_V_DATA, (u32)(Data));
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_LO_V_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_conv_top_Get_lo_v(XY26_conv_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_LO_V_DATA);
    Data += (u64)XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_LO_V_DATA + 4) << 32;
    return Data;
}

void XY26_conv_top_Set_Y(XY26_conv_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_Y_DATA, (u32)(Data));
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_conv_top_Get_Y(XY26_conv_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_Y_DATA);
    Data += (u64)XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XY26_conv_top_Set_H(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_H_DATA, Data);
}

u32 XY26_conv_top_Get_H(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_H_DATA);
    return Data;
}

void XY26_conv_top_Set_W(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_W_DATA, Data);
}

u32 XY26_conv_top_Get_W(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_W_DATA);
    return Data;
}

void XY26_conv_top_Set_oc(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_OC_DATA, Data);
}

u32 XY26_conv_top_Get_oc(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_OC_DATA);
    return Data;
}

void XY26_conv_top_Set_ic(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_IC_DATA, Data);
}

u32 XY26_conv_top_Get_ic(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_IC_DATA);
    return Data;
}

void XY26_conv_top_Set_kh(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_KH_DATA, Data);
}

u32 XY26_conv_top_Get_kh(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_KH_DATA);
    return Data;
}

void XY26_conv_top_Set_kw(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_KW_DATA, Data);
}

u32 XY26_conv_top_Get_kw(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_KW_DATA);
    return Data;
}

void XY26_conv_top_Set_sh(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_SH_DATA, Data);
}

u32 XY26_conv_top_Get_sh(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_SH_DATA);
    return Data;
}

void XY26_conv_top_Set_sw(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_SW_DATA, Data);
}

u32 XY26_conv_top_Get_sw(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_SW_DATA);
    return Data;
}

void XY26_conv_top_Set_ph(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_PH_DATA, Data);
}

u32 XY26_conv_top_Get_ph(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_PH_DATA);
    return Data;
}

void XY26_conv_top_Set_pw(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_PW_DATA, Data);
}

u32 XY26_conv_top_Get_pw(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_PW_DATA);
    return Data;
}

void XY26_conv_top_Set_groups(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_GROUPS_DATA, Data);
}

u32 XY26_conv_top_Get_groups(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_GROUPS_DATA);
    return Data;
}

void XY26_conv_top_Set_act(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_ACT_DATA, Data);
}

u32 XY26_conv_top_Get_act(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_ACT_DATA);
    return Data;
}

void XY26_conv_top_Set_perch(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_PERCH_DATA, Data);
}

u32 XY26_conv_top_Get_perch(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_PERCH_DATA);
    return Data;
}

void XY26_conv_top_Set_step(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_STEP_DATA, Data);
}

u32 XY26_conv_top_Get_step(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_STEP_DATA);
    return Data;
}

void XY26_conv_top_Set_lo(XY26_conv_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_LO_DATA, Data);
}

u32 XY26_conv_top_Get_lo(XY26_conv_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_LO_DATA);
    return Data;
}

void XY26_conv_top_InterruptGlobalEnable(XY26_conv_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_GIE, 1);
}

void XY26_conv_top_InterruptGlobalDisable(XY26_conv_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_GIE, 0);
}

void XY26_conv_top_InterruptEnable(XY26_conv_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_IER);
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XY26_conv_top_InterruptDisable(XY26_conv_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_IER);
    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XY26_conv_top_InterruptClear(XY26_conv_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_conv_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XY26_conv_top_InterruptGetEnabled(XY26_conv_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_IER);
}

u32 XY26_conv_top_InterruptGetStatus(XY26_conv_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XY26_conv_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_CONV_TOP_CONTROL_ADDR_ISR);
}

