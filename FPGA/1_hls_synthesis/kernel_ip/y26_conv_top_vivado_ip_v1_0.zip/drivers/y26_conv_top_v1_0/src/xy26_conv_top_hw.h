// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x010 : Data signal of X
//         bit 31~0 - X[31:0] (Read/Write)
// 0x014 : Data signal of X
//         bit 31~0 - X[63:32] (Read/Write)
// 0x018 : reserved
// 0x01c : Data signal of Wt
//         bit 31~0 - Wt[31:0] (Read/Write)
// 0x020 : Data signal of Wt
//         bit 31~0 - Wt[63:32] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of wsc
//         bit 31~0 - wsc[31:0] (Read/Write)
// 0x02c : Data signal of wsc
//         bit 31~0 - wsc[63:32] (Read/Write)
// 0x030 : reserved
// 0x034 : Data signal of bias
//         bit 31~0 - bias[31:0] (Read/Write)
// 0x038 : Data signal of bias
//         bit 31~0 - bias[63:32] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of step_v
//         bit 31~0 - step_v[31:0] (Read/Write)
// 0x044 : Data signal of step_v
//         bit 31~0 - step_v[63:32] (Read/Write)
// 0x048 : reserved
// 0x04c : Data signal of lo_v
//         bit 31~0 - lo_v[31:0] (Read/Write)
// 0x050 : Data signal of lo_v
//         bit 31~0 - lo_v[63:32] (Read/Write)
// 0x054 : reserved
// 0x058 : Data signal of Y
//         bit 31~0 - Y[31:0] (Read/Write)
// 0x05c : Data signal of Y
//         bit 31~0 - Y[63:32] (Read/Write)
// 0x060 : reserved
// 0x064 : Data signal of H
//         bit 31~0 - H[31:0] (Read/Write)
// 0x068 : reserved
// 0x06c : Data signal of W
//         bit 31~0 - W[31:0] (Read/Write)
// 0x070 : reserved
// 0x074 : Data signal of oc
//         bit 31~0 - oc[31:0] (Read/Write)
// 0x078 : reserved
// 0x07c : Data signal of ic
//         bit 31~0 - ic[31:0] (Read/Write)
// 0x080 : reserved
// 0x084 : Data signal of kh
//         bit 31~0 - kh[31:0] (Read/Write)
// 0x088 : reserved
// 0x08c : Data signal of kw
//         bit 31~0 - kw[31:0] (Read/Write)
// 0x090 : reserved
// 0x094 : Data signal of sh
//         bit 31~0 - sh[31:0] (Read/Write)
// 0x098 : reserved
// 0x09c : Data signal of sw
//         bit 31~0 - sw[31:0] (Read/Write)
// 0x0a0 : reserved
// 0x0a4 : Data signal of ph
//         bit 31~0 - ph[31:0] (Read/Write)
// 0x0a8 : reserved
// 0x0ac : Data signal of pw
//         bit 31~0 - pw[31:0] (Read/Write)
// 0x0b0 : reserved
// 0x0b4 : Data signal of groups
//         bit 31~0 - groups[31:0] (Read/Write)
// 0x0b8 : reserved
// 0x0bc : Data signal of act
//         bit 31~0 - act[31:0] (Read/Write)
// 0x0c0 : reserved
// 0x0c4 : Data signal of perch
//         bit 31~0 - perch[31:0] (Read/Write)
// 0x0c8 : reserved
// 0x0cc : Data signal of step
//         bit 31~0 - step[31:0] (Read/Write)
// 0x0d0 : reserved
// 0x0d4 : Data signal of lo
//         bit 31~0 - lo[31:0] (Read/Write)
// 0x0d8 : reserved
// 0x0dc : Data signal of Yc
//         bit 31~0 - Yc[31:0] (Read/Write)
// 0x0e0 : Data signal of Yc
//         bit 31~0 - Yc[63:32] (Read/Write)
// 0x0e4 : reserved
// 0x0e8 : Data signal of yq
//         bit 31~0 - yq[31:0] (Read/Write)
// 0x0ec : reserved
// 0x0f0 : Data signal of q_k
//         bit 31~0 - q_k[31:0] (Read/Write)
// 0x0f4 : Data signal of q_k
//         bit 31~0 - q_k[63:32] (Read/Write)
// 0x0f8 : reserved
// 0x0fc : Data signal of q_b
//         bit 31~0 - q_b[31:0] (Read/Write)
// 0x100 : Data signal of q_b
//         bit 31~0 - q_b[63:32] (Read/Write)
// 0x104 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL     0x000
#define XY26_CONV_TOP_CONTROL_ADDR_GIE         0x004
#define XY26_CONV_TOP_CONTROL_ADDR_IER         0x008
#define XY26_CONV_TOP_CONTROL_ADDR_ISR         0x00c
#define XY26_CONV_TOP_CONTROL_ADDR_X_DATA      0x010
#define XY26_CONV_TOP_CONTROL_BITS_X_DATA      64
#define XY26_CONV_TOP_CONTROL_ADDR_WT_DATA     0x01c
#define XY26_CONV_TOP_CONTROL_BITS_WT_DATA     64
#define XY26_CONV_TOP_CONTROL_ADDR_WSC_DATA    0x028
#define XY26_CONV_TOP_CONTROL_BITS_WSC_DATA    64
#define XY26_CONV_TOP_CONTROL_ADDR_BIAS_DATA   0x034
#define XY26_CONV_TOP_CONTROL_BITS_BIAS_DATA   64
#define XY26_CONV_TOP_CONTROL_ADDR_STEP_V_DATA 0x040
#define XY26_CONV_TOP_CONTROL_BITS_STEP_V_DATA 64
#define XY26_CONV_TOP_CONTROL_ADDR_LO_V_DATA   0x04c
#define XY26_CONV_TOP_CONTROL_BITS_LO_V_DATA   64
#define XY26_CONV_TOP_CONTROL_ADDR_Y_DATA      0x058
#define XY26_CONV_TOP_CONTROL_BITS_Y_DATA      64
#define XY26_CONV_TOP_CONTROL_ADDR_H_DATA      0x064
#define XY26_CONV_TOP_CONTROL_BITS_H_DATA      32
#define XY26_CONV_TOP_CONTROL_ADDR_W_DATA      0x06c
#define XY26_CONV_TOP_CONTROL_BITS_W_DATA      32
#define XY26_CONV_TOP_CONTROL_ADDR_OC_DATA     0x074
#define XY26_CONV_TOP_CONTROL_BITS_OC_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_IC_DATA     0x07c
#define XY26_CONV_TOP_CONTROL_BITS_IC_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_KH_DATA     0x084
#define XY26_CONV_TOP_CONTROL_BITS_KH_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_KW_DATA     0x08c
#define XY26_CONV_TOP_CONTROL_BITS_KW_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_SH_DATA     0x094
#define XY26_CONV_TOP_CONTROL_BITS_SH_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_SW_DATA     0x09c
#define XY26_CONV_TOP_CONTROL_BITS_SW_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_PH_DATA     0x0a4
#define XY26_CONV_TOP_CONTROL_BITS_PH_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_PW_DATA     0x0ac
#define XY26_CONV_TOP_CONTROL_BITS_PW_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_GROUPS_DATA 0x0b4
#define XY26_CONV_TOP_CONTROL_BITS_GROUPS_DATA 32
#define XY26_CONV_TOP_CONTROL_ADDR_ACT_DATA    0x0bc
#define XY26_CONV_TOP_CONTROL_BITS_ACT_DATA    32
#define XY26_CONV_TOP_CONTROL_ADDR_PERCH_DATA  0x0c4
#define XY26_CONV_TOP_CONTROL_BITS_PERCH_DATA  32
#define XY26_CONV_TOP_CONTROL_ADDR_STEP_DATA   0x0cc
#define XY26_CONV_TOP_CONTROL_BITS_STEP_DATA   32
#define XY26_CONV_TOP_CONTROL_ADDR_LO_DATA     0x0d4
#define XY26_CONV_TOP_CONTROL_BITS_LO_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_YC_DATA     0x0dc
#define XY26_CONV_TOP_CONTROL_BITS_YC_DATA     64
#define XY26_CONV_TOP_CONTROL_ADDR_YQ_DATA     0x0e8
#define XY26_CONV_TOP_CONTROL_BITS_YQ_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_Q_K_DATA    0x0f0
#define XY26_CONV_TOP_CONTROL_BITS_Q_K_DATA    64
#define XY26_CONV_TOP_CONTROL_ADDR_Q_B_DATA    0x0fc
#define XY26_CONV_TOP_CONTROL_BITS_Q_B_DATA    64

