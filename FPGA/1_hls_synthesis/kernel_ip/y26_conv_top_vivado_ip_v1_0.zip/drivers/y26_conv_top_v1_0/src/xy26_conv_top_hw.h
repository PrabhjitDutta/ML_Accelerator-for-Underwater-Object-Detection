// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of X
//        bit 31~0 - X[31:0] (Read/Write)
// 0x14 : Data signal of X
//        bit 31~0 - X[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of Wt
//        bit 31~0 - Wt[31:0] (Read/Write)
// 0x20 : Data signal of Wt
//        bit 31~0 - Wt[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of wsc
//        bit 31~0 - wsc[31:0] (Read/Write)
// 0x2c : Data signal of wsc
//        bit 31~0 - wsc[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of bias
//        bit 31~0 - bias[31:0] (Read/Write)
// 0x38 : Data signal of bias
//        bit 31~0 - bias[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of step_v
//        bit 31~0 - step_v[31:0] (Read/Write)
// 0x44 : Data signal of step_v
//        bit 31~0 - step_v[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of lo_v
//        bit 31~0 - lo_v[31:0] (Read/Write)
// 0x50 : Data signal of lo_v
//        bit 31~0 - lo_v[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of Y
//        bit 31~0 - Y[31:0] (Read/Write)
// 0x5c : Data signal of Y
//        bit 31~0 - Y[63:32] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of H
//        bit 31~0 - H[31:0] (Read/Write)
// 0x68 : reserved
// 0x6c : Data signal of W
//        bit 31~0 - W[31:0] (Read/Write)
// 0x70 : reserved
// 0x74 : Data signal of oc
//        bit 31~0 - oc[31:0] (Read/Write)
// 0x78 : reserved
// 0x7c : Data signal of ic
//        bit 31~0 - ic[31:0] (Read/Write)
// 0x80 : reserved
// 0x84 : Data signal of kh
//        bit 31~0 - kh[31:0] (Read/Write)
// 0x88 : reserved
// 0x8c : Data signal of kw
//        bit 31~0 - kw[31:0] (Read/Write)
// 0x90 : reserved
// 0x94 : Data signal of sh
//        bit 31~0 - sh[31:0] (Read/Write)
// 0x98 : reserved
// 0x9c : Data signal of sw
//        bit 31~0 - sw[31:0] (Read/Write)
// 0xa0 : reserved
// 0xa4 : Data signal of ph
//        bit 31~0 - ph[31:0] (Read/Write)
// 0xa8 : reserved
// 0xac : Data signal of pw
//        bit 31~0 - pw[31:0] (Read/Write)
// 0xb0 : reserved
// 0xb4 : Data signal of groups
//        bit 31~0 - groups[31:0] (Read/Write)
// 0xb8 : reserved
// 0xbc : Data signal of act
//        bit 31~0 - act[31:0] (Read/Write)
// 0xc0 : reserved
// 0xc4 : Data signal of perch
//        bit 31~0 - perch[31:0] (Read/Write)
// 0xc8 : reserved
// 0xcc : Data signal of step
//        bit 31~0 - step[31:0] (Read/Write)
// 0xd0 : reserved
// 0xd4 : Data signal of lo
//        bit 31~0 - lo[31:0] (Read/Write)
// 0xd8 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XY26_CONV_TOP_CONTROL_ADDR_AP_CTRL     0x00
#define XY26_CONV_TOP_CONTROL_ADDR_GIE         0x04
#define XY26_CONV_TOP_CONTROL_ADDR_IER         0x08
#define XY26_CONV_TOP_CONTROL_ADDR_ISR         0x0c
#define XY26_CONV_TOP_CONTROL_ADDR_X_DATA      0x10
#define XY26_CONV_TOP_CONTROL_BITS_X_DATA      64
#define XY26_CONV_TOP_CONTROL_ADDR_WT_DATA     0x1c
#define XY26_CONV_TOP_CONTROL_BITS_WT_DATA     64
#define XY26_CONV_TOP_CONTROL_ADDR_WSC_DATA    0x28
#define XY26_CONV_TOP_CONTROL_BITS_WSC_DATA    64
#define XY26_CONV_TOP_CONTROL_ADDR_BIAS_DATA   0x34
#define XY26_CONV_TOP_CONTROL_BITS_BIAS_DATA   64
#define XY26_CONV_TOP_CONTROL_ADDR_STEP_V_DATA 0x40
#define XY26_CONV_TOP_CONTROL_BITS_STEP_V_DATA 64
#define XY26_CONV_TOP_CONTROL_ADDR_LO_V_DATA   0x4c
#define XY26_CONV_TOP_CONTROL_BITS_LO_V_DATA   64
#define XY26_CONV_TOP_CONTROL_ADDR_Y_DATA      0x58
#define XY26_CONV_TOP_CONTROL_BITS_Y_DATA      64
#define XY26_CONV_TOP_CONTROL_ADDR_H_DATA      0x64
#define XY26_CONV_TOP_CONTROL_BITS_H_DATA      32
#define XY26_CONV_TOP_CONTROL_ADDR_W_DATA      0x6c
#define XY26_CONV_TOP_CONTROL_BITS_W_DATA      32
#define XY26_CONV_TOP_CONTROL_ADDR_OC_DATA     0x74
#define XY26_CONV_TOP_CONTROL_BITS_OC_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_IC_DATA     0x7c
#define XY26_CONV_TOP_CONTROL_BITS_IC_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_KH_DATA     0x84
#define XY26_CONV_TOP_CONTROL_BITS_KH_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_KW_DATA     0x8c
#define XY26_CONV_TOP_CONTROL_BITS_KW_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_SH_DATA     0x94
#define XY26_CONV_TOP_CONTROL_BITS_SH_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_SW_DATA     0x9c
#define XY26_CONV_TOP_CONTROL_BITS_SW_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_PH_DATA     0xa4
#define XY26_CONV_TOP_CONTROL_BITS_PH_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_PW_DATA     0xac
#define XY26_CONV_TOP_CONTROL_BITS_PW_DATA     32
#define XY26_CONV_TOP_CONTROL_ADDR_GROUPS_DATA 0xb4
#define XY26_CONV_TOP_CONTROL_BITS_GROUPS_DATA 32
#define XY26_CONV_TOP_CONTROL_ADDR_ACT_DATA    0xbc
#define XY26_CONV_TOP_CONTROL_BITS_ACT_DATA    32
#define XY26_CONV_TOP_CONTROL_ADDR_PERCH_DATA  0xc4
#define XY26_CONV_TOP_CONTROL_BITS_PERCH_DATA  32
#define XY26_CONV_TOP_CONTROL_ADDR_STEP_DATA   0xcc
#define XY26_CONV_TOP_CONTROL_BITS_STEP_DATA   32
#define XY26_CONV_TOP_CONTROL_ADDR_LO_DATA     0xd4
#define XY26_CONV_TOP_CONTROL_BITS_LO_DATA     32

