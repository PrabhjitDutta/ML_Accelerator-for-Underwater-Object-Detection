// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xy26_conv_top.h"

extern XY26_conv_top_Config XY26_conv_top_ConfigTable[];

#ifdef SDT
XY26_conv_top_Config *XY26_conv_top_LookupConfig(UINTPTR BaseAddress) {
	XY26_conv_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XY26_conv_top_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XY26_conv_top_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XY26_conv_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XY26_conv_top_Initialize(XY26_conv_top *InstancePtr, UINTPTR BaseAddress) {
	XY26_conv_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XY26_conv_top_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XY26_conv_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XY26_conv_top_Config *XY26_conv_top_LookupConfig(u16 DeviceId) {
	XY26_conv_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XY26_CONV_TOP_NUM_INSTANCES; Index++) {
		if (XY26_conv_top_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XY26_conv_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XY26_conv_top_Initialize(XY26_conv_top *InstancePtr, u16 DeviceId) {
	XY26_conv_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XY26_conv_top_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XY26_conv_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

