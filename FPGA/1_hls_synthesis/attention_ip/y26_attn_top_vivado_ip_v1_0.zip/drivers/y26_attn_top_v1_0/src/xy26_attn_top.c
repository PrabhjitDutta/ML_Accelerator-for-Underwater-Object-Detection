// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xy26_attn_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XY26_attn_top_CfgInitialize(XY26_attn_top *InstancePtr, XY26_attn_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XY26_attn_top_Start(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XY26_attn_top_IsDone(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XY26_attn_top_IsIdle(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XY26_attn_top_IsReady(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XY26_attn_top_EnableAutoRestart(XY26_attn_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XY26_attn_top_DisableAutoRestart(XY26_attn_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

void XY26_attn_top_Set_X(XY26_attn_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_X_DATA, (u32)(Data));
    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_attn_top_Get_X(XY26_attn_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_X_DATA);
    Data += (u64)XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XY26_attn_top_Set_Y(XY26_attn_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_Y_DATA, (u32)(Data));
    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_attn_top_Get_Y(XY26_attn_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_Y_DATA);
    Data += (u64)XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XY26_attn_top_Set_nh(XY26_attn_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_NH_DATA, Data);
}

u32 XY26_attn_top_Get_nh(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_NH_DATA);
    return Data;
}

void XY26_attn_top_Set_n(XY26_attn_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_N_DATA, Data);
}

u32 XY26_attn_top_Get_n(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_N_DATA);
    return Data;
}

void XY26_attn_top_Set_m(XY26_attn_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_M_DATA, Data);
}

u32 XY26_attn_top_Get_m(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_M_DATA);
    return Data;
}

void XY26_attn_top_Set_g(XY26_attn_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_G_DATA, Data);
}

u32 XY26_attn_top_Get_g(XY26_attn_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_G_DATA);
    return Data;
}

void XY26_attn_top_InterruptGlobalEnable(XY26_attn_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_GIE, 1);
}

void XY26_attn_top_InterruptGlobalDisable(XY26_attn_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_GIE, 0);
}

void XY26_attn_top_InterruptEnable(XY26_attn_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_IER);
    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XY26_attn_top_InterruptDisable(XY26_attn_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_IER);
    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XY26_attn_top_InterruptClear(XY26_attn_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_attn_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XY26_attn_top_InterruptGetEnabled(XY26_attn_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_IER);
}

u32 XY26_attn_top_InterruptGetStatus(XY26_attn_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XY26_attn_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_ATTN_TOP_CONTROL_ADDR_ISR);
}

