// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xy26_ops_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XY26_ops_top_CfgInitialize(XY26_ops_top *InstancePtr, XY26_ops_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XY26_ops_top_Start(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XY26_ops_top_IsDone(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XY26_ops_top_IsIdle(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XY26_ops_top_IsReady(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XY26_ops_top_EnableAutoRestart(XY26_ops_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XY26_ops_top_DisableAutoRestart(XY26_ops_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

void XY26_ops_top_Set_Sa(XY26_ops_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SA_DATA, (u32)(Data));
    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SA_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_ops_top_Get_Sa(XY26_ops_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SA_DATA);
    Data += (u64)XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SA_DATA + 4) << 32;
    return Data;
}

void XY26_ops_top_Set_Sb(XY26_ops_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SB_DATA, (u32)(Data));
    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SB_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_ops_top_Get_Sb(XY26_ops_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SB_DATA);
    Data += (u64)XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_SB_DATA + 4) << 32;
    return Data;
}

void XY26_ops_top_Set_Dst(XY26_ops_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_DST_DATA, (u32)(Data));
    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_DST_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_ops_top_Get_Dst(XY26_ops_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_DST_DATA);
    Data += (u64)XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_DST_DATA + 4) << 32;
    return Data;
}

void XY26_ops_top_Set_Par(XY26_ops_top *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_PAR_DATA, (u32)(Data));
    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_PAR_DATA + 4, (u32)(Data >> 32));
}

u64 XY26_ops_top_Get_Par(XY26_ops_top *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_PAR_DATA);
    Data += (u64)XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_PAR_DATA + 4) << 32;
    return Data;
}

void XY26_ops_top_Set_C(XY26_ops_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_C_DATA, Data);
}

u32 XY26_ops_top_Get_C(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_C_DATA);
    return Data;
}

void XY26_ops_top_Set_units(XY26_ops_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_UNITS_DATA, Data);
}

u32 XY26_ops_top_Get_units(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_UNITS_DATA);
    return Data;
}

void XY26_ops_top_Set_amode(XY26_ops_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AMODE_DATA, Data);
}

u32 XY26_ops_top_Get_amode(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_AMODE_DATA);
    return Data;
}

void XY26_ops_top_Set_bmode(XY26_ops_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_BMODE_DATA, Data);
}

u32 XY26_ops_top_Get_bmode(XY26_ops_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_BMODE_DATA);
    return Data;
}

void XY26_ops_top_InterruptGlobalEnable(XY26_ops_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_GIE, 1);
}

void XY26_ops_top_InterruptGlobalDisable(XY26_ops_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_GIE, 0);
}

void XY26_ops_top_InterruptEnable(XY26_ops_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_IER);
    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XY26_ops_top_InterruptDisable(XY26_ops_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_IER);
    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XY26_ops_top_InterruptClear(XY26_ops_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XY26_ops_top_WriteReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XY26_ops_top_InterruptGetEnabled(XY26_ops_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_IER);
}

u32 XY26_ops_top_InterruptGetStatus(XY26_ops_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XY26_ops_top_ReadReg(InstancePtr->Control_BaseAddress, XY26_OPS_TOP_CONTROL_ADDR_ISR);
}

