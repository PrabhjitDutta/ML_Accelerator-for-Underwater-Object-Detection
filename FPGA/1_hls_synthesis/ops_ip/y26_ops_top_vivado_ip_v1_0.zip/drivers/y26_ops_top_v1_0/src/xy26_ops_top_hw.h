// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of Sa
//        bit 31~0 - Sa[31:0] (Read/Write)
// 0x14 : Data signal of Sa
//        bit 31~0 - Sa[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of Sb
//        bit 31~0 - Sb[31:0] (Read/Write)
// 0x20 : Data signal of Sb
//        bit 31~0 - Sb[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of Dst
//        bit 31~0 - Dst[31:0] (Read/Write)
// 0x2c : Data signal of Dst
//        bit 31~0 - Dst[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of Par
//        bit 31~0 - Par[31:0] (Read/Write)
// 0x38 : Data signal of Par
//        bit 31~0 - Par[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of C
//        bit 31~0 - C[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of units
//        bit 31~0 - units[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of amode
//        bit 31~0 - amode[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of bmode
//        bit 31~0 - bmode[31:0] (Read/Write)
// 0x5c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XY26_OPS_TOP_CONTROL_ADDR_AP_CTRL    0x00
#define XY26_OPS_TOP_CONTROL_ADDR_GIE        0x04
#define XY26_OPS_TOP_CONTROL_ADDR_IER        0x08
#define XY26_OPS_TOP_CONTROL_ADDR_ISR        0x0c
#define XY26_OPS_TOP_CONTROL_ADDR_SA_DATA    0x10
#define XY26_OPS_TOP_CONTROL_BITS_SA_DATA    64
#define XY26_OPS_TOP_CONTROL_ADDR_SB_DATA    0x1c
#define XY26_OPS_TOP_CONTROL_BITS_SB_DATA    64
#define XY26_OPS_TOP_CONTROL_ADDR_DST_DATA   0x28
#define XY26_OPS_TOP_CONTROL_BITS_DST_DATA   64
#define XY26_OPS_TOP_CONTROL_ADDR_PAR_DATA   0x34
#define XY26_OPS_TOP_CONTROL_BITS_PAR_DATA   64
#define XY26_OPS_TOP_CONTROL_ADDR_C_DATA     0x40
#define XY26_OPS_TOP_CONTROL_BITS_C_DATA     32
#define XY26_OPS_TOP_CONTROL_ADDR_UNITS_DATA 0x48
#define XY26_OPS_TOP_CONTROL_BITS_UNITS_DATA 32
#define XY26_OPS_TOP_CONTROL_ADDR_AMODE_DATA 0x50
#define XY26_OPS_TOP_CONTROL_BITS_AMODE_DATA 32
#define XY26_OPS_TOP_CONTROL_ADDR_BMODE_DATA 0x58
#define XY26_OPS_TOP_CONTROL_BITS_BMODE_DATA 32

