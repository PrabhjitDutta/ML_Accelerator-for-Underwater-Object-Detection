// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
// Tool Version Limit: 2026.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XY26_OPS_TOP_H
#define XY26_OPS_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xy26_ops_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XY26_ops_top_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XY26_ops_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XY26_ops_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XY26_ops_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XY26_ops_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XY26_ops_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XY26_ops_top_Initialize(XY26_ops_top *InstancePtr, UINTPTR BaseAddress);
XY26_ops_top_Config* XY26_ops_top_LookupConfig(UINTPTR BaseAddress);
#else
int XY26_ops_top_Initialize(XY26_ops_top *InstancePtr, u16 DeviceId);
XY26_ops_top_Config* XY26_ops_top_LookupConfig(u16 DeviceId);
#endif
int XY26_ops_top_CfgInitialize(XY26_ops_top *InstancePtr, XY26_ops_top_Config *ConfigPtr);
#else
int XY26_ops_top_Initialize(XY26_ops_top *InstancePtr, const char* InstanceName);
int XY26_ops_top_Release(XY26_ops_top *InstancePtr);
#endif

void XY26_ops_top_Start(XY26_ops_top *InstancePtr);
u32 XY26_ops_top_IsDone(XY26_ops_top *InstancePtr);
u32 XY26_ops_top_IsIdle(XY26_ops_top *InstancePtr);
u32 XY26_ops_top_IsReady(XY26_ops_top *InstancePtr);
void XY26_ops_top_EnableAutoRestart(XY26_ops_top *InstancePtr);
void XY26_ops_top_DisableAutoRestart(XY26_ops_top *InstancePtr);

void XY26_ops_top_Set_Sa(XY26_ops_top *InstancePtr, u64 Data);
u64 XY26_ops_top_Get_Sa(XY26_ops_top *InstancePtr);
void XY26_ops_top_Set_Sb(XY26_ops_top *InstancePtr, u64 Data);
u64 XY26_ops_top_Get_Sb(XY26_ops_top *InstancePtr);
void XY26_ops_top_Set_Dst(XY26_ops_top *InstancePtr, u64 Data);
u64 XY26_ops_top_Get_Dst(XY26_ops_top *InstancePtr);
void XY26_ops_top_Set_Par(XY26_ops_top *InstancePtr, u64 Data);
u64 XY26_ops_top_Get_Par(XY26_ops_top *InstancePtr);
void XY26_ops_top_Set_C(XY26_ops_top *InstancePtr, u32 Data);
u32 XY26_ops_top_Get_C(XY26_ops_top *InstancePtr);
void XY26_ops_top_Set_units(XY26_ops_top *InstancePtr, u32 Data);
u32 XY26_ops_top_Get_units(XY26_ops_top *InstancePtr);
void XY26_ops_top_Set_amode(XY26_ops_top *InstancePtr, u32 Data);
u32 XY26_ops_top_Get_amode(XY26_ops_top *InstancePtr);
void XY26_ops_top_Set_bmode(XY26_ops_top *InstancePtr, u32 Data);
u32 XY26_ops_top_Get_bmode(XY26_ops_top *InstancePtr);

void XY26_ops_top_InterruptGlobalEnable(XY26_ops_top *InstancePtr);
void XY26_ops_top_InterruptGlobalDisable(XY26_ops_top *InstancePtr);
void XY26_ops_top_InterruptEnable(XY26_ops_top *InstancePtr, u32 Mask);
void XY26_ops_top_InterruptDisable(XY26_ops_top *InstancePtr, u32 Mask);
void XY26_ops_top_InterruptClear(XY26_ops_top *InstancePtr, u32 Mask);
u32 XY26_ops_top_InterruptGetEnabled(XY26_ops_top *InstancePtr);
u32 XY26_ops_top_InterruptGetStatus(XY26_ops_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
